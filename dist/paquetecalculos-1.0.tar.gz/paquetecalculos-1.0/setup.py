from setuptools import setup

setup(
    name="paquetecalculos",
    version="1.0",
    description="Paquete de redondeo y potencia",
    author="Pedro",
    author_email = "cursos@miscuros.com",
    packages=['calculos','calculos.redondeo_potencia']
)