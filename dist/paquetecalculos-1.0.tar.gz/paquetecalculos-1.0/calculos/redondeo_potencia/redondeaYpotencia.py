def potencia(base,exponente):
    print("El resultado es: ", base**exponente)

def redondear(numero):
    print("El numero redondeado es: ", round(numero))    
